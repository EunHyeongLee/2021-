import { Task } from './Task';

export const TASKS: Task[] = [
  // {
  //   id: 1,
  //   text: 'Doctors Appointment',
  //   day: 'May 5th at 2:30pm',
  //   reminder: true,
  //   completed:false
  // },
  // {
  //   id: 2,
  //   text: 'Meeting at School',
  //   day: 'May 6th at 1:30pm',
  //   reminder: true,
  //   completed:false
  // },
  // {
  //   id: 3,
  //   text: 'Food Shopping',
  //   day: 'May 7th at 12:30pm',
  //   reminder: false,
  //   completed:false
  // },
];

// {
//   "tasks": [
//     {
//       "text": "test",
//       "day": "August 10th at 12:00pm",
//       "reminder": false,
//       "completed": false,
//       "id": 1
//     },
//     {
//       "text": "review report",
//       "day": "August 11th at 11:30am",
//       "reminder": false,
//       "completed": false,
//       "id": 2
//     },
//     {
//       "text": "send account invitation",
//       "day": "August 11th at 1:00pm",
//       "reminder": false,
//       "completed": false,
//       "id": 3
//     },
//     {
//       "text": "Email Professor",
//       "day": "August 8th at 2:00pm",
//       "reminder": false,
//       "completed": false,
//       "id": 4
//     }
//   ]
// }