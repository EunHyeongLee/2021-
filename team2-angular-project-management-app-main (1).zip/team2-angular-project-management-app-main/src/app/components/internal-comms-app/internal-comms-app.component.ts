import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-internal-comms-app',
  templateUrl: './internal-comms-app.component.html',
  styleUrls: ['./internal-comms-app.component.css']
})
export class InternalCommsAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
