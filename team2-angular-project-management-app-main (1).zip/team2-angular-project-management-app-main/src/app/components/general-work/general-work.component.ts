import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-work',
  templateUrl: './general-work.component.html',
  styleUrls: ['./general-work.component.css']
})
export class GeneralWorkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
